/**
 * Tutorial 1 Details
 *  Data Types
 *  Variables
 */

/*
    Most Common Programming Case types

    1. camelCase
    2. kebab-case
    3. snake_case
    4. PascalCase
*/

console.log('Tutorial 1');

/* Variables in JavaScript
   Rules for creating JS Variable
        -->can not start with number
        -->can start with letter, number and _
        --> case sensitive

 How to define Variables: var, let, const

 var : used to store data globally
 
 let : Used to store data locally
        --> Block level Scope

 const: Used to store fixed value that can not change later 

*/
const ownerName = 'Disha . R . Trivedi';
// ownerName = 'Harry'; can't do this as ownername is defined by datatype const


/**
 * Data Types in JavaScript
 * 1. Primitive DataType
 *      Memory allocation in stack
 *    Types of Primitive DataTypes
 *    --> numbers, string, Boolean, Null, Undefined, Symbol
 * 
 * 2. Reference DataType
 *      Memory allocation dynamically
 *     Types of Reference DataTypes
 *      --> object Literals, Arrays, Functions, Dates
 */

// 1. Primitive DataTypes

var temp;
console.log(" Type of temp is '", typeof(temp), "' with value : ", temp);

var tempNull = null;
console.log(" Type of temp is '", typeof(tempNull), "' with value : ", tempNull);


// String Primitive DataType

var tempString = 'Disha Trivedi';
console.log(" Type of tempString is '", typeof(tempString), "' with value : ", tempString);

// Number Primitive DataType

var tempNumber = 123;
console.log(" Type of tempNumber is '", typeof(tempNumber), "' with value : ", tempNumber);

// Boolean Primitive DataType

var tempBoolean = true;
console.log(" Type of tempBoolean is '", typeof(tempBoolean), "' with value : ", tempBoolean);

// Decimal Primitive DataType

var tempDecimal = 123.321;
console.log(" Type of tempDecimal is '", typeof(tempDecimal), "' with value : ", tempDecimal);

// Let Block

{
    let tempDecimal = 1.235;
    console.log(" Inside block Decimal value override by using let : ", tempDecimal);
}

console.log(" Outside Block Decimal value after using let :", tempDecimal);


// 2. Reference DataTypes


// Array Reference DataType

var tempArray = [12, 23, 34, 45, 56, 67, 78, 89, 90];
console.log(" Type of tempArray is '", typeof(tempArray), "' with values : ", tempArray);

// Object Reference DataType

var tempObject = {
    id: 'name',
    key: 'password'
};

console.log(" Type of tempObject is '", typeof(tempObject), "' with values : ", tempObject);

// Function Reference DataType

function tempFunction() {

}

console.log(" Type of tempObject is '", typeof(tempFunction), "' with values : ", tempFunction);

// Date Reference DataType

var tempDate = new Date();
console.log(" Type of tempDate is '", typeof(tempDate), "' with values : ", tempDate);