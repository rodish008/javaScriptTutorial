/**
 * Tutorial 2
 *  Type Conversion and Type Coercion
 * 
 */

console.log("Tutorial 2");

var myVar = 34;
console.log("My Variable value is :", myVar, " with type ", typeof(myVar));

// String Conversion

myVar = String(myVar);

console.log("After type conversion type of my variable is ", typeof myVar, " and the value inside this variable is :", myVar);

let date = String(new Date());
console.log(date, (typeof date));

var number = 90;
console.log("Number is : ", number, " with type (", typeof(number), ")and now the conversation from number to string the value is : ", number.toString(), "and type of value is (", typeof(number.toString()), ")");

// Use of parseInt

console.log("I am applying parseInt to 123.321 and we get : ", parseInt(123.321));

// Use of parseFloat

console.log("I am applying parseFloat to 123.321 and we get : ", parseFloat(123));

// Use of toFixed

console.log("Now i am fix the value of 90 by using toFixed and we get : ", number.toFixed(4));