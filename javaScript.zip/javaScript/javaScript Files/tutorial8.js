/**
 * 
 * DOM & Creating website layout
 * 
 */


console.log("Tutorial 8");

// document 

console.log(document);
console.log(document.all);
console.log(document.scripts);
console.log(document.images);
console.log(document.links);

let tempLink = "Google";
let store;

console.log(store = Array.from(document.links).forEach(Element => {

    if (Element.href.includes(tempLink)) {
        console.log(Element);
    } else {
        console.log("Not Available");
    }

}));

// Element Selector

store = document.getElementById('heading');
console.log(document.childNodes);

store.innerHTML = '<b>Hey There</b>'
console.log(store.innerText);

store = document.querySelector('.red');
console.log(store);

// Multi element selector 

let temp;

temp = document.getElementsByClassName('child');
console.log(temp);

temp = document.getElementsByClassName('container');
console.log(temp);

temp = document.getElementsByTagName('div');
console.log(temp);

Array.from(temp).forEach(element => {
    console.log(element);
    element.style.color = 'blue';
});

console.log(temp[0].getElementsByClassName('child'));