/**
 * 
 * Manipulation website using JavaScript Window Object
 * 
 */

console.log("Tutorial 7");

let temp;

var tempDoc = window.document;

// Prompt() to get data from user 

// confirm() to give confirmation 

temp = window.innerHeight;
console.log("Inner height of window is : ", temp);

temp = window.innerWidth;
console.log("Inner width of window is : ", temp);

temp = window.outerHeight;
console.log("Outer height of window is : ", temp);

temp = window.outerWidth;
console.log("Outer width of window is : ", temp);

temp = scrollX;
console.log(" Scrolling in X is : ", temp);

temp = scrollY;
console.log(" Scrolling in Y is : ", temp);

temp = location;
console.log(" Location is : ", temp);

temp = location.toString();
console.log(" Location to string is : ", temp);

temp = window.history;
console.log(" History is : ", temp);