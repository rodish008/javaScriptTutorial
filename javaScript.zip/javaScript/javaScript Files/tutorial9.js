/**
 * 
 * Children, Parent & Traversing the DOM
 * 
 */